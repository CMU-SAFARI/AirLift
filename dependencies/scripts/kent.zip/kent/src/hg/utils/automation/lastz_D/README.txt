
lastz_D tuning procedure scripts, as outlined in:

  http://genomewiki.ucsc.edu/index.php/Lastz_tuning_procedure

The scripts here are slightly different than indicated in
the wiki page.  They have been adjusted here to work with UCSC local
pathnames to assembly sequences and files.
