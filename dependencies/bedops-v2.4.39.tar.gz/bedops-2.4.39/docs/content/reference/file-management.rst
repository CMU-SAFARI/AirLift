File management
===============

.. toctree::

   file-management/sorting
   file-management/compression
   file-management/conversion
