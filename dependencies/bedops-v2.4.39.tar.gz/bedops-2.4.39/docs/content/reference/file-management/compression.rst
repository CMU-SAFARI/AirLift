Compression
===========

.. toctree::

   compression/starch
   compression/unstarch
   compression/starchcat
   compression/starchsplit
   compression/starch-specification
   compression/starch-diff
   
